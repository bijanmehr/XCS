clc; clear;
%fuckin test

r = round(rand*6);
temp = [1 1 1 1 1 1 1 1 1];
temp(1,r) = -1;
temp;